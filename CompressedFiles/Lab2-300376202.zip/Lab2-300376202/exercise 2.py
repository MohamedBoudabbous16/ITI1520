#Mohamed Boudabbous
#300376202
def celsius_en_fahrenheit(temp_Celsius):

    temp_Fahrenheit=(9/5)*(temp_Celsius+(32*(5/9)))
    print ('la temperatrure en fahrenheit est', temp_Fahrenheit)
    


celsius_en_fahrenheit(32)
celsius_en_fahrenheit(40)
celsius_en_fahrenheit(210)

