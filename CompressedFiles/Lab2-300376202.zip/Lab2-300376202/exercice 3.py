#Mohamed Boudabbous
#300376202
def calcule (devoirsMoyenne, partiel, examen):
    note=devoirsMoyenne*25/100 + partiel*25/100 + examen*50/100
    print('La note finale est', note)
calcule(80,100,50)
calcule(90,60,50)
calcule(80,100,50)
calcule(85,65,45)
