#Mohamed Boudabbous
#300376202
a=int(input('entrez le premier nombre'))
b=int(input('entrez le deuxiéme nombre'))
e=a//b
r=a%b
print('resultat de la division entiére du pre,ier nombre par le deuxieme est', e)
print('le restant la division du 1 er nombre par le deuxieme',r)
