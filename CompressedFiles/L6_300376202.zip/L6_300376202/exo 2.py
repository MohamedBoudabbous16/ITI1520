#Mohamed Boudabbous
#300376202
#exo2
aha='abcdefgh'
print(aha[0:4])
print(aha[3:6])
print(aha[-1])
print(aha[5:7])
print(aha[3:])
print(aha[5:])
print(aha[0]+aha[3]+aha[6])
print(aha[1]+aha[3])
