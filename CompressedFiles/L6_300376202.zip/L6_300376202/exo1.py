#Mohamed Boudabbous
#300376202
#exo1
s1='bon'
s2="mauvais"
s3="fou"
L="ou" in s3
print(L)
V=" " in s1
print(V)
S= s1+s2+s3
print(S)
print(10*s3)
print(len(S))
