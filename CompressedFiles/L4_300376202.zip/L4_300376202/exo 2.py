#Mohamed Boudabbous
#300376202
#exercice 2
n=int(input('Entrez un nombre'))
while (n>=0):
        for i in range(n):
            n=n-i
            print(i+1)
