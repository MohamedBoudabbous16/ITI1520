#Mohamed Boudabbous
#300376202
#exercice 1
compteur = 10
while(compteur >=1):
    print(compteur)
    compteur = compteur - 1
